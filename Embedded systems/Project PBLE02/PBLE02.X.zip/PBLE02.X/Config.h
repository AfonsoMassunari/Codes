#ifndef CONFIG_H
#define	CONFIG_H

    #pragma config MCLRE=ON
    #pragma config FOSC=HS
    #pragma config WDT=OFF
    #pragma config LVP=OFF
    #pragma config ICPRT=ON



#endif	/* CONFIG_H */
