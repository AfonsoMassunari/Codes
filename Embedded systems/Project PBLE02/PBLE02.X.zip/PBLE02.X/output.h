#ifndef OUTPUT_H
#define	OUTPUT_H
void outputInit(void);
void outputPrint(int numTela, int idioma);

#endif	/* OUTPUT_H */

