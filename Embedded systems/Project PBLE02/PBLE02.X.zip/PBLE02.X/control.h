#ifndef CONTROL_H
#define	CONTROL_H

void controlSet(int ad2read);


#endif	/* CONTROL_H */

