#ifndef ADC_H
	#define ADC_H

	void adcInit(void);
	int adcRead(unsigned int channel);

#endif