#ifndef PWM_H
	#define PWM_H

	void pwmSet(unsigned char porcento);
	void pwmFrequency(unsigned int freq);
	void pwmInit(void);


#endif //PWM_H