#ifndef KEYPAD_H
	#define KEYPAD_H

	unsigned char kpRead(void);
	void kpDebounce(void);
	void kpInit(void);

#endif